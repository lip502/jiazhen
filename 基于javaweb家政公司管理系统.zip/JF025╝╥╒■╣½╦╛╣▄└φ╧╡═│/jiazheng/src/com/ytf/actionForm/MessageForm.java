package com.ytf.actionForm;
//�û�������Ϣʵ��
public class MessageForm {
			private String messageForm;
			/**
			 * @return the messageForm
			 */
			public String getMessageForm() {
				return messageForm;
			}
			/**
			 * @param messageForm the messageForm to set
			 */
			public void setMessageForm(String messageForm) {
				this.messageForm = messageForm;
			}

}

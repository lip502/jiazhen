package com.ytf.actionForm;
//����ʵ��
public class NewsForm {
	//���ű��
	private int id;
	//���ű���
	private String title;
	//��������
	private String content;
	//��������
	private String issuedate;
	//�������
	private String type;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * @return the content
	 */
	public String getContent() {
		return content;
	}
	/**
	 * @param content the content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}
	/**
	 * @return the issuedate
	 */
	public String getIssuedate() {
		return issuedate;
	}
	/**
	 * @param issuedate the issuedate to set
	 */
	public void setIssuedate(String issuedate) {
		this.issuedate = issuedate;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	

}

package com.ytf.actionForm;

public class QueryBmInfoForm {
	//����ÿ�칤��ʱ��
	private int workTime;
	//����ʳ��Ҫ��
	private int accomm;
	//�����ṩ�ķ�������
	private int workType;
	//���������е�֤��
	private int cert;
	//���������ռ���
	private int skill;
	//��������������
	private int lang;
	//���������ղ�ϵ
	private int flavor;
	//���̼���
	private String homeCity;
	/**
	 * @return the workTime
	 */
	public int getWorkTime() {
		return workTime;
	}
	/**
	 * @param workTime the workTime to set
	 */
	public void setWorkTime(int workTime) {
		this.workTime = workTime;
	}
	/**
	 * @return the isCommom
	 */
	public int getAccomm() {
		return accomm;
	}
	/**
	 * @param isCommom the isCommom to set
	 */
	public void setAccomm(int accomm) {
		this.accomm = accomm;
	}
	/**
	 * @return the workType
	 */
	public int getWorkType() {
		return workType;
	}
	/**
	 * @param workType the workType to set
	 */
	public void setWorkType(int workType) {
		this.workType = workType;
	}
	/**
	 * @return the cert
	 */
	public int getCert() {
		return cert;
	}
	/**
	 * @param cert the cert to set
	 */
	public void setCert(int cert) {
		this.cert = cert;
	}
	/**
	 * @return the skill
	 */
	public int getSkill() {
		return skill;
	}
	/**
	 * @param skill the skill to set
	 */
	public void setSkill(int skill) {
		this.skill = skill;
	}
	/**
	 * @return the lang
	 */
	public int getLang() {
		return lang;
	}
	/**
	 * @param lang the lang to set
	 */
	public void setLang(int lang) {
		this.lang = lang;
	}
	/**
	 * @return the flavor
	 */
	public int getFlavor() {
		return flavor;
	}
	/**
	 * @param flavor the flavor to set
	 */
	public void setFlavor(int flavor) {
		this.flavor = flavor;
	}
	/**
	 * @return the homeCity
	 */
	public String getHomeCity() {
		return homeCity;
	}
	/**
	 * @param homeCity the homeCity to set
	 */
	public void setHomeCity(String homeCity) {
		this.homeCity = homeCity;
	}

}

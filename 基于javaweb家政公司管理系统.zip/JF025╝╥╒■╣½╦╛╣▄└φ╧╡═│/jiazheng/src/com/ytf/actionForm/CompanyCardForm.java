package com.ytf.actionForm;
/*
 * ������Ƭʵ��
 */
public class CompanyCardForm {
	//������˾����
	private String name;
	//������˾��Ӫҵ��
	private String desc;
	//������˾��ϵ��
	private String linkman;
	//������˾��ϵ��ʽ
	private String contacts;
	//������˾������Ƭʱ��
	private String upTime;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the desc
	 */
	public String getDesc() {
		return desc;
	}
	/**
	 * @param desc the desc to set
	 */
	public void setDesc(String desc) {
		this.desc = desc;
	}
	/**
	 * @return the linkman
	 */
	public String getLinkman() {
		return linkman;
	}
	/**
	 * @param linkman the linkman to set
	 */
	public void setLinkman(String linkman) {
		this.linkman = linkman;
	}
	/**
	 * @return the contacts
	 */
	public String getContacts() {
		return contacts;
	}
	/**
	 * @param contacts the contacts to set
	 */
	public void setContacts(String contacts) {
		this.contacts = contacts;
	}
	/**
	 * @return the upTime
	 */
	public String getUpTime() {
		return upTime;
	}
	/**
	 * @param upTime the upTime to set
	 */
	public void setUpTime(String upTime) {
		this.upTime = upTime;
	}
	

}
